# flowcontainer
Get basic flow information from pcap, such as packet length sequence, packet arrival time sequence, source IP/port, destination IP/port, start and end time.
# Usgae
- Install
```
pip3 install git+https://github.com/jmhIcoding/flowcontainer.git
```
- Example code
`example.py` script shows a good example to use this library. 

# Documents
https://blog.csdn.net/jmh1996/article/details/107148871 
